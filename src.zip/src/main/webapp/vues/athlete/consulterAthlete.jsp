<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="sio.la2028.model.*"%>
<%@page import="java.time.format.DateTimeFormatter" %>
<%!
    public String getFilename(String code) {
        if (code == null) return "fr";
        switch (code.toUpperCase()) {
            case "FRA": return "fr";
            case "USA": return "us";
            case "ALG": return "dz";
            case "GER": return "de";
            case "ANT": return "ag";
            case "ARG": return "ar";
            case "AUS": return "au";
            case "AZE": return "az";
            case "BLR": return "by";
            case "BEL": return "be";
            case "ALB": return "al";
            default: return code.toLowerCase();
        }
    }

    public String getAthleteImageFilename(String prenom, String nom) {
        if (prenom == null || nom == null) return "default";
        String fullName = (prenom + " " + nom).trim();
        if (fullName.contains("Mélanie")) return "Mélanie_De_Jesus_dos_Santos";
        if (fullName.contains("Wout")) return "Wout_Van_Aert";
        if (fullName.contains("Diego")) return "Diego_Sebastián_Schwartzman";
        if (fullName.contains("Sydney")) return "Sydney_McLaughlin";
        return (prenom.trim() + "_" + nom.trim()).replaceAll("\\s+", "_");
    }

    // Nouvelle fonction pour la gestion des images de sport
    public String getSportImageFilename(String sportName) {
        if (sportName == null) return "default";
        String name = sportName.trim().toLowerCase();
        if (name.contains("gymnastique")) return "gymnastique";
        return name.replaceAll("\\s+", "_");
    }
%>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Profil Athlète | LA28 BETTING</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Teko:wght@500;700;900&display=swap" rel="stylesheet">
    <style>
        :root { --bg: #050507; --surface: #0f1015; --pink: #FF004D; --text: #fff; --border: #1f2129; --muted: #9499ad; }
        body { font-family: 'Inter', sans-serif; background: var(--bg); color: var(--text); margin: 0; padding-bottom: 60px; }

        .topbar { display: flex; justify-content: space-between; align-items: center; padding: 20px 50px; background: rgba(5,5,7,0.9); border-bottom: 1px solid var(--border); position: sticky; top: 0; z-index: 100; backdrop-filter: blur(10px); }
        .logo { font-family: 'Teko', sans-serif; font-size: 2.5rem; color: var(--text); text-decoration: none; line-height: 1; }
        .logo span { color: var(--pink); }

        .container { max-width: 950px; margin: 60px auto; padding: 0 20px; }

        .player-card-huge { background: var(--surface); border: 1px solid var(--border); padding: 50px; position: relative; overflow: hidden; }
        .player-card-huge::after { content: ''; position: absolute; bottom: 0; right: 0; width: 300px; height: 300px; background: radial-gradient(circle, rgba(255,0,77,0.15) 0%, transparent 70%); }

        .player-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid var(--border); padding-bottom: 25px; margin-bottom: 40px; position: relative; z-index: 2; flex-wrap: wrap; gap: 20px; }

        .identity-group { display: flex; align-items: center; gap: 30px; flex: 1; min-width: 0; }
        .athlete-avatar { width: 140px; height: 140px; object-fit: cover; border: 2px solid var(--pink); box-shadow: 0 0 25px rgba(255,0,77,0.4); clip-path: polygon(12px 0, 100% 0, calc(100% - 12px) 100%, 0 100%); background: #16181f; flex-shrink: 0; }

        .names { display: flex; flex-direction: column; min-width: 0; overflow: hidden; }
        .first-name { font-family: 'Teko', sans-serif; font-size: 2.5rem; color: var(--muted); line-height: 0.8; text-transform: uppercase; }
        .last-name { font-family: 'Teko', sans-serif; font-size: clamp(2.5rem, 5vw, 5rem); font-weight: 900; line-height: 0.95; text-transform: uppercase; color: var(--text); word-break: break-word; }

        .country-box { display: flex; align-items: center; gap: 15px; background: rgba(255,255,255,0.03); border: 1px solid var(--border); padding: 15px 25px; white-space: nowrap; flex-shrink: 0; }
        .country-flag { width: 50px; height: auto; border-radius: 3px; box-shadow: 0 4px 10px rgba(0,0,0,0.5); object-fit: cover; }
        .country-name { font-family: 'Teko', sans-serif; font-size: 2rem; text-transform: uppercase; letter-spacing: 1px; line-height: 1; color: var(--text); }

        .data-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; position: relative; z-index: 2; }
        .data-box { border: 1px solid var(--border); padding: 25px; background: rgba(5,5,7,0.5); }
        .data-label { font-size: 0.8rem; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px; font-weight: 600; }
        .data-value { font-family: 'Teko', sans-serif; font-size: 2.5rem; color: var(--pink); line-height: 1; text-transform: uppercase; }

        /* Style pour l'encadré de la discipline */
        .sport-box { display: flex; align-items: center; justify-content: space-between; gap: 15px; }
        .sport-image { width: 70px; height: 70px; object-fit: cover; border-radius: 4px; border: 1px solid var(--pink); box-shadow: 0 0 10px rgba(255,0,77,0.2); flex-shrink: 0; }

        .back-btn { font-family: 'Teko', sans-serif; font-size: 1.5rem; color: var(--text); text-decoration: none; display: inline-block; margin-top: 40px; padding: 10px 30px; border: 1px solid var(--border); transition: 0.3s; }
        .back-btn:hover { background: var(--text); color: var(--bg); }
    </style>
</head>
<body>
<header class="topbar">
    <a href="../index.html" class="logo">LA28<span>BET</span></a>
</header>

<div class="container">
    <% Athlete a = (Athlete)request.getAttribute("pAthlete"); %>

    <div class="player-card-huge">
        <div class="player-header">
            <div class="identity-group">
                <img src="<%= request.getContextPath() %>/vues/image/<%= getAthleteImageFilename(a.getPrenom(), a.getNom()) %>.jpg"
                     alt="<%= a.getPrenom() %> <%= a.getNom() %>"
                     class="athlete-avatar"
                     onerror="this.style.display='none'">
                <div class="names">
                    <span class="first-name"><%= a.getPrenom() %></span>
                    <span class="last-name"><%= a.getNom() %></span>
                </div>
            </div>
            <div class="country-box">
                <% if(a.getPays() != null && a.getPays().getCode() != null) { %>
                <img src="<%= request.getContextPath() %>/vues/image/<%= getFilename(a.getPays().getCode()) %>.png" alt="" class="country-flag">
                <% } %>
                <span class="country-name"><%= a.getPays().getNom() %></span>
            </div>
        </div>

        <div class="data-grid">
            <!-- Box Sport modifiée pour inclure l'image -->
            <div class="data-box sport-box">
                <div>
                    <div class="data-label">Discipline / Spécialité</div>
                    <div class="data-value"><%= a.getSport().getNom() %></div>
                </div>
                <img src="<%= request.getContextPath() %>/vues/image/<%= getSportImageFilename(a.getSport().getNom()) %>.jpg"
                     alt="<%= a.getSport().getNom() %>"
                     class="sport-image"
                     onerror="this.style.display='none'">
            </div>
            <div class="data-box">
                <div class="data-label">Date de Naissance</div>
                <div class="data-value" style="color: var(--text);"><%= a.getDateNaissance().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")) %></div>
            </div>
        </div>
    </div>
    <a href="../ServletAthlete/lister" class="back-btn">RETOUR AU ROSTER</a>
</div>
</body>
</html>